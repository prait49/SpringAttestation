package com.example.finalattestation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalAttestationApplicationTests {

    @Test
    void contextLoads() {
    }

}
