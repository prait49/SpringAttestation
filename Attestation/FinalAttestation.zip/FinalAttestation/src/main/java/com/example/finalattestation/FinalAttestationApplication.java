package com.example.finalattestation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalAttestationApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalAttestationApplication.class, args);
    }

}
