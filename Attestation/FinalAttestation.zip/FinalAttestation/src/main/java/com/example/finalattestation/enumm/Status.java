package com.example.finalattestation.enumm;

public enum Status {
    Ожидает, Оформлен, Получен, Принят;

}

